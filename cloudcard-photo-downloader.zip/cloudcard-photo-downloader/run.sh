java -jar cloudcard-photo-downloader.jar >> downloader.log
