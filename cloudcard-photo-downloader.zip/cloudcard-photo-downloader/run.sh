java -jar cloudcard-photo-downloader.jar
